
import React from 'react';
import { CountryMacroData } from '../types';

interface CountryCardProps {
  data: CountryMacroData;
  countryName: string;
  onClick: () => void;
}

const CountryCard: React.FC<CountryCardProps> = ({ data, countryName, onClick }) => {
  const latest = data.historicalData[data.historicalData.length - 1];
  const sourceCount = data.sources?.length || 0;

  // Determine inflation status color
  const getCpiColor = (val: number) => {
    if (val > 5) return 'text-rose-600'; // High inflation
    if (val > 2.5) return 'text-amber-600'; // Moderate
    return 'text-emerald-600'; // Stable
  };

  return (
    <div 
      onClick={onClick}
      className="bg-white border border-slate-200 rounded-[2.5rem] p-8 hover:shadow-[0_40px_100px_-20px_rgba(0,0,0,0.1)] transition-all cursor-pointer group flex flex-col h-full border-b-8 border-b-indigo-500/10 hover:border-b-indigo-500 hover:-translate-y-2 duration-500"
    >
      <div className="flex justify-between items-start mb-8">
        <div>
          <h3 className="text-3xl font-black text-slate-900 leading-none tracking-tighter mb-2 group-hover:text-indigo-600 transition-colors">
            {countryName}
          </h3>
          <div className="flex items-center space-x-2">
            <p className="text-[10px] text-indigo-600 font-black uppercase tracking-[0.2em]">{data.currency}</p>
            {data.isSearchGrounded ? (
              <span className="flex items-center text-[9px] font-black text-emerald-600 bg-emerald-50 px-2.5 py-1 rounded-full border border-emerald-100 uppercase tracking-tighter">
                <svg className="w-2.5 h-2.5 mr-1" fill="currentColor" viewBox="0 0 20 20"><path d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z"/></svg>
                {sourceCount} Verified
              </span>
            ) : (
              <span className="flex items-center text-[9px] font-black text-slate-400 bg-slate-50 px-2.5 py-1 rounded-full border border-slate-100 uppercase tracking-tighter">
                Model Synthesis
              </span>
            )}
          </div>
        </div>
        <div className="flex flex-col items-end">
          <span className="text-[10px] font-black px-3 py-1 bg-slate-900 rounded-xl text-white shadow-lg shadow-slate-200 mb-2">{latest.year}</span>
        </div>
      </div>

      <div className="space-y-6 flex-1">
        <div className="grid grid-cols-2 gap-4">
          {/* Main Retailer Metric: Retail Sales */}
          <div className="space-y-1.5 p-4 bg-indigo-50/30 rounded-[1.5rem] border border-indigo-100/50 group-hover:bg-indigo-50 transition-colors">
            <p className="text-[9px] font-black text-indigo-400 uppercase tracking-widest">Retail Sales</p>
            <div className="flex items-baseline space-x-1">
              <span className={`text-2xl font-black ${latest.retailSales > 0 ? 'text-indigo-700' : 'text-rose-600'}`}>
                {latest.retailSales > 0 ? '+' : ''}{latest.retailSales}%
              </span>
            </div>
          </div>

          {/* Main Retailer Metric: Consumer Confidence */}
          <div className="space-y-1.5 p-4 bg-slate-50/50 rounded-[1.5rem] border border-slate-100 group-hover:bg-white transition-colors">
            <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Confidence (CCI)</p>
            <div className="flex items-baseline space-x-1">
              <span className="text-2xl font-black text-slate-900">{latest.cci}</span>
              <span className="text-[9px] text-slate-400 font-bold uppercase">idx</span>
            </div>
          </div>

          {/* Critical Pressure: Inflation */}
          <div className="space-y-1.5 p-4 bg-slate-50/50 rounded-[1.5rem] border border-slate-100 group-hover:bg-white transition-colors">
            <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Inflation (CPI)</p>
            <div className="flex items-baseline space-x-1">
              <span className={`text-2xl font-black ${getCpiColor(latest.cpi)}`}>{latest.cpi}%</span>
            </div>
          </div>

          {/* Labor Health: Unemployment */}
          <div className="space-y-1.5 p-4 bg-slate-50/50 rounded-[1.5rem] border border-slate-100 group-hover:bg-white transition-colors">
            <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Unemployment</p>
            <div className="flex items-baseline space-x-1">
              <span className={`text-2xl font-black ${latest.unemploymentRate > 7 ? 'text-rose-600' : 'text-slate-800'}`}>
                {latest.unemploymentRate}%
              </span>
            </div>
          </div>
        </div>

        <div className="flex flex-wrap gap-2">
          <span className="px-3 py-1.5 bg-slate-900 text-white border border-slate-800 rounded-xl text-[9px] font-black uppercase tracking-widest shadow-md">
            E-Comm: {latest.ecommercePenetration}%
          </span>
          <span className="px-3 py-1.5 bg-white border border-slate-200 rounded-xl text-[9px] font-black text-slate-500 uppercase tracking-widest">
            {latest.yieldCurve} Yield
          </span>
        </div>
      </div>

      <div className="mt-8 pt-6 border-t border-slate-100 flex justify-between items-center">
        <div className="group/gdp">
          <p className="text-[8px] font-black text-slate-400 uppercase tracking-[0.2em] mb-1">Total Market Output (GDP)</p>
          <span className="text-lg font-black text-slate-900 tracking-tighter">{data.currentGDP}</span>
        </div>
        <div className="w-12 h-12 rounded-2xl bg-slate-900 flex items-center justify-center text-white group-hover:bg-indigo-600 group-hover:rotate-[15deg] group-hover:scale-110 transition-all duration-500 shadow-xl shadow-slate-200">
          <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M17 8l4 4m0 0l-4 4m4-4H3" /></svg>
        </div>
      </div>
    </div>
  );
};

export default CountryCard;
