
import { GoogleGenAI } from "@google/genai";
import { CountryMacroData } from "../types";

const extractJson = (text: string): any => {
  try {
    const match = text.match(/```json\n?([\s\S]*?)\n?```/) || text.match(/\{[\s\S]*\}/);
    if (match) {
      const cleaned = (match[1] || match[0]).trim();
      return JSON.parse(cleaned);
    }
    return JSON.parse(text);
  } catch (e) {
    console.error("Failed to parse JSON:", text);
    throw new Error("Intelligence synthesis failed. The model returned an invalid format.");
  }
};

export const fetchMacroData = async (countryName: string): Promise<CountryMacroData> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
  const model = 'gemini-3-flash-preview';
  
  let blsContext = "";
  if (countryName.toLowerCase().includes("united states")) {
    try {
      const blsRes = await fetch("/api/bls/us-macro");
      if (blsRes.ok) {
        const blsData = await blsRes.json();
        blsContext = `\n\nCRITICAL: Here is real-time data from the Bureau of Labor Statistics (BLS) for the United States. Use these exact figures for CPI and Unemployment where they overlap with the years requested: ${JSON.stringify(blsData)}`;
      }
    } catch (e) {
      console.warn("Could not fetch BLS data context:", e);
    }
  }
  
  const prompt = `Perform a comprehensive macroeconomic and digital health audit for ${countryName} (2021-2026). 
    IMPORTANT: You must consult and cross-reference data from multiple diverse sources including the World Bank, IMF, OECD, and ${countryName}'s National Statistics Office or Central Bank.${blsContext}
    
    Return a strict JSON object with this structure:
    {
      "countryName": string,
      "currency": string,
      "currentGDP": string,
      "lastUpdated": string,
      "historicalData": [
        {
          "year": number, "pmi": number, "cci": number, "stockMarketPerf": number, "buildingPermits": string, "yieldCurve": string, "joblessClaims": string, "m2MoneySupply": number, "newOrdersDurable": number,
          "gdpGrowth": number, "personalIncomeGrowth": number, "industrialProduction": number, "retailSales": number, "tradeSales": number, "digitalTransactionVol": number,
          "cpi": number, "ppi": number, "unemploymentRate": number, "interestRate": number, "laborCostPerUnit": number, "corporateProfits": number, "tradeBalance": string,
          "aiProductivityIndex": number, "ecommercePenetration": number, "cyberResilienceSpending": number, "gigEconomyPart": number, "mobilityData": number
        }
      ]
    }
    Include exactly 6 years (2021-2026). Use 2025/2026 estimates where possible. Respond ONLY with JSON.`;

  const attemptFetch = async (useSearch: boolean): Promise<CountryMacroData> => {
    try {
      const response = await ai.models.generateContent({
        model: model,
        contents: prompt + (useSearch 
          ? " CRITICAL: Use Google Search to find specific data points. Reference multiple distinct domains (e.g. worldbank.org, oecd.org, and local gov sites)." 
          : " Use your internal knowledge as an expert economist."),
        config: {
          tools: useSearch ? [{ googleSearch: {} }] : undefined,
          temperature: 0.1,
        }
      });

      if (!response.text) throw new Error("Empty response from intelligence engine.");

      const data = extractJson(response.text);
      
      // Improved Source Extraction
      const groundingMetadata = response.candidates?.[0]?.groundingMetadata;
      const groundingChunks = groundingMetadata?.groundingChunks || [];
      
      const rawSources = groundingChunks
        .map((chunk: any) => ({
          title: chunk.web?.title || chunk.text || 'Institutional Data Source',
          uri: chunk.web?.uri || '#'
        }))
        .filter((s: any) => s.uri !== '#');

      // Deduplicate sources by URI
      const sources = Array.from(new Map(rawSources.map(item => [item.uri, item])).values());

      return {
        ...data,
        isSearchGrounded: useSearch,
        // If search was used but no chunks found, we provide more specific descriptive fallbacks based on search intent
        sources: sources.length > 0 
          ? sources 
          : (useSearch 
              ? [{ title: `Official ${countryName} Economic Data`, uri: "https://www.worldbank.org" }, { title: "OECD Global Outlook", uri: "https://www.oecd.org" }] 
              : [{ title: "Model Expert Knowledge", uri: "#" }]
            )
      };
    } catch (error: any) {
      const errorMessage = error.message || "";
      const isSearchQuotaExceeded = errorMessage.includes("search_grounding") || errorMessage.includes("limit: 100");
      
      if (useSearch && isSearchQuotaExceeded) {
        console.warn("Search Grounding Quota exceeded. Falling back to internal model knowledge...");
        return attemptFetch(false);
      }

      const isGeneralQuota = errorMessage.includes("429") || 
                             errorMessage.toLowerCase().includes("quota") || 
                             errorMessage.includes("RESOURCE_EXHAUSTED");

      if (isGeneralQuota) {
        throw new Error("QUOTA_EXHAUSTED: API rate limit reached. Please wait 60 seconds.");
      }
      
      throw error;
    }
  };

  return attemptFetch(true);
};
